<?php

namespace App\Http\Controllers;

use App\Models\Adminforms;
use Illuminate\Http\Request;

class AdminformsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        {
            $Adminforms = Adminforms::latest()->paginate(5);
        
            return view('Adminforms.index',compact('Adminforms'))
                ->with('i', (request()->input('page', 1) - 1) * 5);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('Adminforms.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([


            'price' => 'required',
            'prack' => 'required',
            'time' => 'required',
            'locationf' => 'required',
            'locationt' => 'required',
            'Agance' => 'required',
                    ]);
    
        Adminforms::create($request->all());
     
        return redirect()->route('Adminforms.index')
                        ->with('success','Adminforms created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Adminforms  $Adminforms
     * @return \Illuminate\Http\Response
     */
    public function show(Adminforms $Adminforms)
    {
        return view('Adminforms.show',compact('Adminforms'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Adminforms $Adminforms
     * @return \Illuminate\Http\Response
     */
    public function edit(Adminforms $Adminforms)
    {
        return view('Adminforms.edit',compact('Adminforms'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Adminforms  $Adminforms
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Adminforms $Adminforms)
    {
        $request->validate([
            'name' => 'required',
            'detail' => 'required',
        ]);
    
        $Adminforms->update($request->all());
    
        return redirect()->route('Adminforms.index')
                        ->with('success','Adminforms updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Adminforms  $Adminforms
     * @return \Illuminate\Http\Response
     */
    public function destroy(Adminforms $Adminforms)
    {
        $Adminforms->delete();
    
        return redirect()->route('Adminforms.index')
                        ->with('success','Adminforms deleted successfully');
    }
}

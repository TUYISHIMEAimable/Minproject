<?php

namespace App\Http\Controllers;

use App\Models\tasksads;
use Illuminate\Http\Request;

class tasksadsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       
        $taskads= tasksads::latest()->paginate(5);
    
        return view('tasksads.index',compact('taskads'))
            ->with('i', (request()->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('tasksads.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'price' => 'required',
            'prack' => 'required',
            'time' => 'required',

            'locationf' => 'required',
            'locationt' => 'required',
            'Agance' => 'required',
        ]);
    
        tasksads::create($request->all());
     
        return redirect()->route('tasksads.index')
                        ->with('success','tasksads created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\tasksads  $taskads
     * @return \Illuminate\Http\Response
     */
    public function show(tasksads $taskads)
    {
        return view('tasksads.show',compact('tasksads'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\tasksads  $taskads
     * @return \Illuminate\Http\Response
     */
    public function edit(tasksads $taskads)
    {
        return view('tasksads.edit',compact('tasksads'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\tasksads  $taskads
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, tasksads $taskads)
    {
        $request->validate([
            'price' => 'required',
            'prack' => 'required',
            'time' => 'required',
            'locationf' => 'required',
            'locationt' => 'required',
            'Agance' => 'required',
        ]);
    
        $taskads->update($request->all());
    
        return redirect()->route('tasksads.index')
                        ->with('success','tasksads updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\tasksads  $taskads
     * @return \Illuminate\Http\Response
     */
    public function destroy(tasksads $taskads)
    {
        $taskads->delete();
    
        return redirect()->route('tasksads.index')
                        ->with('success','tasksads deleted successfully');
    }
}

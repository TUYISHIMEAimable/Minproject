<?php

namespace App\Http\Controllers;

use App\Models\adminform;
use Illuminate\Http\Request;

class AdminformController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        {
            $adminform = adminform::latest()->paginate(5);
        
            return view('adminforms.index',compact('adminform'))
                ->with('i', (request()->input('page', 1) - 1) * 5);
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('adminform.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([


            'price' => 'required',
            'prack' => 'required',
            'time' => 'required',
            'locationf' => 'required',
            'locationt' => 'required',
            'Agance' => 'required',
                    ]);
    
        Adminform::create($request->all());
     
        return redirect()->route('adminform.index')
                        ->with('success','Adminform created successfully.');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\adminform  $adminform
     * @return \Illuminate\Http\Response
     */
    public function show(adminform $adminform)
    {
        return view('Adminform.show',compact('adminform'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\adminform  $adminform
     * @return \Illuminate\Http\Response
     */
    public function edit(adminform $adminform)
    {
        return view('adminform.edit',compact('adminform'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\adminform  $adminform
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, adminform $adminform)
    {
        $request->validate([
            'name' => 'required',
            'detail' => 'required',
        ]);
    
        $Adminform->update($request->all());
    
        return redirect()->route('adminform.index')
                        ->with('success','Adminform updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\adminform  $adminform
     * @return \Illuminate\Http\Response
     */
    public function destroy(adminform $adminform)
    {
        $Adminform->delete();
    
        return redirect()->route('Adminforms.index')
                        ->with('success','Adminform deleted successfully');
    }
}

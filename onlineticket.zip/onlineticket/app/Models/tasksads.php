<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class tasksads extends Model
{
    use HasFactory;
    protected $fillable = [
        'price','prack','time','locationf','locationt','Agance'
    ];
}

<html>
<head><style >
	a{text-decoration:none;}
	</style>
</head>
<body >
<center>
	<table bgcolor="#ccccff">
		<tr style = "background-color: #4B5320; color:white">

			
				<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
		</tr>
	  <tr >

			
				<?php echo $__env->make('left_side_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			

			<td colspan = "5" ><h1>
				Welcome to UNIVERSAL Online Ticket </h1><p><Strong>ONLINE TICKET</Strong> is an application used to help any person who want to go from PROVENCES to KIGALI City.</p>

 				<img src = "/images/bus1.gif" height  = "220" width = "380">
 				<img src = "/images/bas2.gif" height  = "220" width = "370">
			</td>
		</tr>
<tr>
			
				<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
</tr>
	</table>
</center>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\onlineticket\resources\views//form/home.blade.php ENDPATH**/ ?>

 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('tasksads.create')); ?>"> Create New task</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
        <th>Set price </th>
            <th>Set car with prack</th>
            <th>Set Time</th>
            <th>Set location from</th>
            <th>Set location Go</th>
            <th>Select Agance </th>
        </tr>
        <?php $__currentLoopData = $taskads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $taskads): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($tasksads->price); ?></td>
            <td><?php echo e($tasksads->prack); ?></td>
            <td><?php echo e($tasksads->time); ?></td>
            <td><?php echo e($tasksads->locationf); ?></td>
            <td><?php echo e($tasksads->locationt); ?></td>
            <td><?php echo e($tasksads->Agence); ?></td>


            <td>
                <form action="<?php echo e(route('tasksads.destroy',$tasksads->id)); ?>" method="POST">
   
                    <a class="btn btn-info" href="<?php echo e(route('tasksads.show',$tasksads->id)); ?>">Show</a>
    
                    <a class="btn btn-primary" href="<?php echo e(route('tasksads.edit',$tasksads->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $taskads->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasksads.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineticket\resources\views/tasksads/index.blade.php ENDPATH**/ ?>
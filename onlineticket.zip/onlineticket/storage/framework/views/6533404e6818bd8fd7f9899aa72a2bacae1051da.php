
  
<?php $__env->startSection('content'); ?>
<style >
	a{text-decoration:none;}
	</style>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New task</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo e(route('tasksads.index')); ?>"> Back</a>
        </div>
    </div>
</div>
   
<?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
   
<form action="<?php echo e(route('tasksads.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <table border="1" bgcolor="#ccccff" align = "center"  >
		<tr style = "background-color: #4B5320; color:white">
			
			
        <?php echo $__env->make('header_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
		</tr>
	  <tr >

			
			<td colspan = "3" ><h1>
				<center>Welcome to Adimin Taskes</center> </h1><p><Strong>ONLINE TICKET set activities</Strong>             
			</td>
    


			<tr><th>Set price </th><td> <input type = "text" name = "price" size = "30" placeholder = "set price" required></td>
			<td rowspan = "8" > <a href="changer_password"><h2>Change your Password</h2></a> </td>
			 </tr>
			 

             <tr><th>Set car with prack </th><td> <input type = "text" name = "prack" size = "30" placeholder = "set car with prack" required></td></tr>
             <tr><th>Set Time </th><td> <input type = "text" name = "time" size = "30" placeholder = "time" required></td></tr>			
             <tr><th>Set location  from</th><td> <input type = "text" name = "locationf" size = "30" placeholder = " is from where" required></td></tr>
             <tr><th>Set location to </th><td> <input type = "text" name = "locationt" size = "30" placeholder = "is go where ??" required></td></tr>			
<tr><th> Select Agance </th>

					<td>
  <select name="Agance" >
  <option >----------</option>
  <option value="Differnt">DIFFERENT</option>
  <option value="stella">STELL</option>
  <option value="select">SELECT</option>
  <option value="Fidelity">FIDELTY</option>
  <option value="kigali cotch">KIGALI COTCH</option>
   <option value="Virunga " >VIRUNGA</option>
  </select>
</td>
<tr>
<th> <input type = "submit" value = "save"></th><td><input type = "reset" value = "Clear"></td>
</tr>
		
<tr>
			
				<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			
</tr>
	</table></form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasksads.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineticket\resources\views/tasksads/create.blade.php ENDPATH**/ ?>
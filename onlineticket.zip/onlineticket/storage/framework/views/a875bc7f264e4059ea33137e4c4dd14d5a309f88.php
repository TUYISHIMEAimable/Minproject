<?php
session_start();
?>
</body>
</html>

<td colspan = "4""><img src = "/images/booking.gif" height  = "80" width = "120"><br>
	<?php echo date("d/M/Y"); ?>-<?php echo date("h:i"); ?></td><td  style = "font-size:50px; font-family:Times New Roman", Georgia, Serif;>UNIVERSAL Online Ticket</td>
	<th> <a href="adimin_login"><h2>Admin Login</h2></a> </th>
			


				
				


<?php /**PATH C:\xampp\htdocs\onlineticket\resources\views/header.blade.php ENDPATH**/ ?>

 
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>passanger inforation</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('passangerinfors.create')); ?>"> Create New Passanger</a>
            </div>
        </div>
    </div>
   
    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>
   
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Gender</th>
            <th>Data of Birth</th>
            <th>Telephone number</th>
            <th>E-Mail</th>
            <th>Where are you come ?</th>
            <th>Where are you go?</th>
            <th>National ID</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $passangerinfors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $passangerinfor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e(++$i); ?></td>
            <td><?php echo e($passangerinfor->FirstName); ?></td>
            <td><?php echo e($passangerinfor->LastName); ?></td>
            <td><?php echo e($passangerinfor->Gender); ?></td>
            <td><?php echo e($passangerinfor->DateOfBirth); ?></td>
            <td><?php echo e($passangerinfor->PhoneNumber); ?></td>
            <td><?php echo e($passangerinfor->Email); ?></td>
            <td><?php echo e($passangerinfor->locationFrom); ?></td>
            <td><?php echo e($passangerinfor->locationto); ?></td>
            <td><?php echo e($passangerinfor->n_id); ?></td>
            <td><?php echo e($passangerinfor->Agance); ?></td>

            <td>
                <form action="<?php echo e(route('passangerinfors.destroy',$passangerinfor->id)); ?>" method="POST">
   
                    <a class="btn btn-info" href="<?php echo e(route('passangerinfors.show',$passangerinfor->id)); ?>">Show</a>
    
                    <a class="btn btn-primary" href="<?php echo e(route('passangerinfors.edit',$passangerinfor->id)); ?>">Edit</a>
   
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
  
    <?php echo $passangerinfors->links(); ?>

      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('passangerinfors.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\onlineticket\resources\views/passangerinfors/index.blade.php ENDPATH**/ ?>
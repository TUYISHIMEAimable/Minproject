
	<?php
session_start();
?>
</body>
</html>

<th colspan = "4""><img src = "/images/adimin.gif" height  = "80" width = "120" style = "font-size:50px; font-family:Times New Roman", Georgia, Serif;><h3>UNIVERSAL Online Ticket</h3><br>
	<?php echo date("d/M/Y"); ?>-<?php echo date("h:i"); ?>
	  </th>
	  
	


				
				



			


				
				



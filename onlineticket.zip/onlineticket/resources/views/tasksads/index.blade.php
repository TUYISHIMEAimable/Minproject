@extends('tasksads.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2></h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('tasksads.create') }}"> Create New task</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
        <th>Set price </th>
            <th>Set car with prack</th>
            <th>Set Time</th>
            <th>Set location from</th>
            <th>Set location Go</th>
            <th>Select Agance </th>
        </tr>
        @foreach ($taskads as $taskads)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $taskads->price }}</td>
            <td>{{ $taskads->prack }}</td>
            <td>{{ $taskads->time }}</td>
            <td>{{ $taskads->locationf }}</td>
            <td>{{ $taskads->locationt }}</td>
            <td>{{ $taskads->Agence }}</td>


            <td>
                <form action="{{ route('tasksads.destroy',$taskads->id) }}" method="POST">
   
                    <a class="btn btn-info" href="{{ route('tasksads.show',$taskads->id) }}">Show</a>
    
                    <a class="btn btn-primary" href="{{ route('tasksads.edit',$taskads->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
    {!! $taskads->links() !!}
      
@endsection
@extends('Adminforms.layout')
 
@section('content')
    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Laravel 8 CRUD Example from scratch - ItSolutionStuff.com</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('Adminforms.create') }}"> Create New Adminforms</a>
            </div>
        </div>
    </div>
   
    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif
   
    <table class="table table-bordered">
        <tr>
            <th>Set price </th>
            <th>Set car with prack</th>
            <th>Set Time</th>
            <th>Set location from</th>
            <th>Set location Go</th>
            <th>Select Agance </th>


            <th width="280px">Action</th>
        </tr>
        @foreach ($Adminforms as $Adminforms)
        <tr>
            <td>{{ ++$i }}</td>
            <td>{{ $Adminforms->price }}</td>
            <td>{{ $Adminforms->prack }}</td>

            <td>{{ $Adminforms->time }}</td>
            <td>{{ $Adminforms->locationf }}</td>
            <td>{{ $Adminforms->locationt }}</td>
            <td>{{ $Adminforms->Agance }}</td>



            <td>
                <form action="{{ route('Adminforms.destroy',$Adminforms->id) }}" method="POST">
   
                    <a class="btn btn-info" href="{{ route('Adminforms.show',$Adminforms->id) }}">Show</a>
    
                    <a class="btn btn-primary" href="{{ route('Adminforms.edit',$Adminforms->id) }}">Edit</a>
   
                    @csrf
                    @method('DELETE')
      
                    <button type="submit" class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
        @endforeach
    </table>
  
    {!! $Adminforms->links() !!}
      
@endsection
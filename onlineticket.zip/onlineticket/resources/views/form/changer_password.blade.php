<html>
<head>
<title>User Login</title>
</head>
<body>
	<center>
		<form name="frmUser" method="POST" action="adimin_login.php" align="center" style = "background-color: lightblue; width:400px;margin-top:200px; border-radius: 15px">

			<h3 align="center">Change your Password</h3>
			 Username:<br>
			 <input type="text" name="userName" required size = "30" required>
			 <br>
			 Old Password:<br>
			<input type="password" name="Old_password" required size = "30" required>
			 <br>
			 New Password:<br>
			<input type="password" name="New_password" required size = "30" required>
			<br><br>
			<input type="submit" value="Update"> <input type="reset" value="clear">
		</form>

	</center>
		</body>
</html>
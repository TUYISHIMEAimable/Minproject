<html>
<head><style >
	a{text-decoration:none;}
	</style>
</head>
<body >
<center>
<form action="" method="post">
	<table border="1" bgcolor="#ccccff" align = "center"  >
		<tr style = "background-color: #4B5320; color:white">
			
			<?php
				include("header_admin.php");
			?>
		</tr>
	  <tr >

			
			<td colspan = "3" ><h1>
				<center>Welcome to Adimin Taskes</center> </h1><p><Strong>ONLINE TICKET set activities</Strong>             
			</td>
    


			<tr><th>Set price </th><td> <input type = "text" name = "price" size = "30" placeholder = "set price" required></td>
			<td rowspan = "8" > <a href="changer_password"><h2>Change your Password</h2></a> </td>
			 </tr>
			 

             <tr><th>Set car with prack </th><td> <input type = "text" name = "prack" size = "30" placeholder = "set car with prack" required></td></tr>
             <tr><th>Set Time </th><td> <input type = "text" name = "time" size = "30" placeholder = "time" required></td></tr>			
             <tr><th>Set location  from</th><td> <input type = "text" name = "locationf" size = "30" placeholder = " is from where" required></td></tr>
             <tr><th>Set location to </th><td> <input type = "text" name = "locationt" size = "30" placeholder = "is go where ??" required></td></tr>			
<tr><th> Select Agance </th>

					<td>
  <select >
  <option >----------</option>
  <option value="Differnt">DIFFERENT</option>
  <option value="stella">STELL</option>
  <option value="select">SELECT</option>
  <option value="Fidelity">FIDELTY</option>
  <option value="kigali cotch">KIGALI COTCH</option>
   <option value="Virunga " >VIRUNGA</option>
  </select>
</td>
<tr>
<th> <input type = "submit" value = "save"></th><td><input type = "reset" value = "Clear"></td>
</tr>
		
<tr>
			<?php
				include("footer.php");
			?>
</tr>
	</table></form
</center>
</body>
</html>
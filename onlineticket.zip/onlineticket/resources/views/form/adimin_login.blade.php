<html>
<head>
<title>User Login</title>
</head>
<body>
	<center>
		<form name="frmUser" method="post" action="" align="center" style = "background-color: lightpink; width:400px;margin-top:200px; border-radius: 15px">
			
			<h3 align="center">Admin Login</h3>
			<div  class="message" >
			
			</div>
			 Username:<br>
			 <input type="text" name="userName" required size = "30">
			 <br>
			 Password:<br>
			<input type="password" name="password" required size = "30">
			<br><br>
			<input type="submit" name="submit" value="Login" >
			<a href = "new_account.php">Create Account </a><br><br>
		</form>

	</center>
		</body>
</html>

<html>
<head><style >
	a{text-decoration:none;}
h1 {text-align: center;}
p {text-align: center;}

</style>
</head>
<body>
	<h1>View lacation from KIGALI to PROVENCE</h1>
<form>
<table bgcolor="31E2E8" border="1" align = "center"  >
<tr style = "background-color: #4B5320; color:white">
			
			<?php
				include("header2.php");
			?>
		</tr>

	<tr>
	<th>LOCATION</th>
	<th>PRICE</th>
	<th rowspan="7"><img src = "/images/bus3.gif" height  = "200" width = "380"></th>
</tr>
<tr>
<td><strong>KIGALI-GISENYI</strong></td>
<td><strong>10000Frw</strong></td>

</tr>
<tr>
<td><strong>KIGALI-GICUMBI</strong></td>
<td><strong>1160 Frw</strong></td>
</tr>
<tr>
<td><strong>KIGALI-NYAMASHEKE</strong></td>
<td><strong>6000Frw</strong></td>
</tr>
<td><strong>KIGALI-NYAGATARE</strong></td>
<td><strong>3500 Frw</strong></td>
<tr>
<td><strong>KIGALI-MUSANZE</strong></td>
<td><strong>1790 Frw</strong></td>
</tr>
<tr>
<td><strong>KIGALI-NYAMAGABE</strong></td>
<td><strong>5000 Frw</strong></td>
</tr>
</table>
<p class="aligncenter">
    <img src="/images/arrow.gif"alt="centered image"height= "90" width = "100" />
</p>
<strong></strong><h1><a href="register">Click REGISTER NOW</a></h1></strong><br>
</form>
</body>
</html>
			